<?php
/**
 * @package	HikaShop for Joomla!
 * @version	4.2.2
 * @author	hikashop.com
 * @copyright	(C) 2010-2020 HIKARI SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
?><?php
class BadgeController extends hikashopController{
	var $type='badge';
	var $pkey = 'badge_id';
	var $table = 'badge';
	var $orderingMap ='badge_ordering';
}
